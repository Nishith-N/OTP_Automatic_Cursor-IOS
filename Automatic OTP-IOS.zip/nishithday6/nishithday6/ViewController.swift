//
//  ViewController.swift
//  nishithday6
//
//  Created by Apple on 06/06/22.
//  Copyright © 2022 Apple. All rights reserved.
//

import UIKit

class ViewController: UIViewController,UITextFieldDelegate {
    var mainflag=0
    var nameFlag=0
    var phoneFlag = 0
    var addressFlag = 0
    var emailFlag = 0
    let firstView: UIView = UIView()
    let nameLbl: UILabel = UILabel()
    var nameText: UITextField = UITextField()
    let nameErr: UILabel = UILabel()
    let phoneLbl: UILabel = UILabel()
    var phoneText: UITextField = UITextField()
    let phoneErr: UILabel = UILabel()
    let addressLbl: UILabel = UILabel()
    var addressText: UITextField = UITextField()
    let addressErr: UILabel = UILabel()
    let emailLbl: UILabel = UILabel()
    var emailText: UITextField = UITextField()
    let emailErr: UILabel = UILabel()
    let secondview: UIView = UIView()
    var otp1: UITextField = UITextField()
    var otp2: UITextField = UITextField()
    var otp3: UITextField = UITextField()
    var otp4: UITextField = UITextField()
    let otp1l: UILabel = UILabel()
    let otp2l: UILabel = UILabel()
    let otp3l: UILabel = UILabel()
    let otp4l: UILabel = UILabel()
    
    
    
    
    @IBAction func regBtn(_ sender: UIButton) {
        
        if((nameFlag == 0) && (addressFlag == 0) && (emailFlag == 0) && (phoneFlag == 0))
            {
                mainflag = 1
        }
        else
        {
            mainflag = 0
        }
        if(mainflag == 1)
        {
        self.view.addSubview(secondview)
            self.secondview.isHidden = false
        }
        if(mainflag == 0)
        {
            self.secondview.isHidden = true
            
        }
        
        
        
    }
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.firstView.backgroundColor = UIColor.cyan
        self.firstView.frame = CGRect(x: 56.5, y: 50, width: 300, height: 350)
        self.view.addSubview(firstView)
        self.secondview.backgroundColor = UIColor.green
        self.secondview.frame = CGRect(x: 56.5, y: 451, width: 300, height: 200)
        
        self.nameLbl.text = "Name:"
        self.nameLbl.textColor = UIColor.black
        self.nameLbl.frame = CGRect(x: 25, y: 25
            , width: 100, height: 30)
        self.firstView.addSubview(nameLbl)
    
        self.nameText.layer.cornerRadius = 2
        self.nameText.layer.borderColor = UIColor.black.cgColor
        self.nameText.clipsToBounds = true
        self.nameText.layer.borderWidth = 1.0
        self.nameText.delegate = self
        self.nameText.frame = CGRect(x: 100, y: 25
            , width: 150, height: 30)
        self.firstView.addSubview(nameText)
        
        
        self.nameErr.frame = CGRect(x: 100, y: 60, width: 150, height: 15)
        self.firstView.addSubview(nameErr)
        
        self.phoneLbl.text = "Phone:"
        self.phoneLbl.textColor = UIColor.black
        self.phoneLbl.frame = CGRect(x: 25, y: 85
            , width: 100, height: 30)
        self.firstView.addSubview(phoneLbl)
        
        self.phoneText.layer.cornerRadius = 2.0
        self.phoneText.layer.borderColor = UIColor.black.cgColor
        self.phoneText.clipsToBounds = true
        self.phoneText.delegate = self
        self.phoneText.layer.borderWidth = 1.0
        self.phoneText.frame = CGRect(x: 100, y: 85
            , width: 150, height: 30)
        self.phoneText.keyboardType = UIKeyboardType.numberPad
        let doneToolbar: UIToolbar = UIToolbar(frame: CGRect.init(x: 0, y: 0, width:UIScreen.main.bounds.width, height: 50))
        doneToolbar.barStyle = .blackTranslucent
        
        
        self.phoneErr.frame = CGRect(x: 100, y: 120, width: 150, height: 15)
        self.firstView.addSubview(phoneErr)
        
        let flexSpace = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
        let done: UIBarButtonItem = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(self.doneButtonAction))
        
        let items = [flexSpace, done]
        doneToolbar.items = items
        doneToolbar.sizeToFit()
        phoneText.inputAccessoryView = doneToolbar
        self.firstView.addSubview(phoneText)
        
        self.addressLbl.text = "Address:"
        self.addressLbl.textColor = UIColor.black
        self.addressLbl.frame = CGRect(x: 25, y: 145
            , width: 100, height: 30)
        self.firstView.addSubview(addressLbl)
        
        self.addressText.layer.cornerRadius = 2.0
        self.addressText.layer.borderColor = UIColor.black.cgColor
        self.addressText.clipsToBounds = true
        self.addressText.delegate = self
        self.addressText.layer.borderWidth = 1.0
        self.addressText.frame = CGRect(x: 100, y: 145
            , width: 150, height: 30)
        self.firstView.addSubview(addressText)
        self.addressErr.frame = CGRect(x: 100, y: 180, width: 150, height: 15)
        self.firstView.addSubview(addressErr)
        
        self.emailLbl.text = "Email:"
        self.emailLbl.textColor = UIColor.black
        self.emailLbl.frame = CGRect(x: 25, y: 205
            , width: 100, height: 30)
        self.firstView.addSubview(emailLbl)
        
        self.emailText.layer.cornerRadius = 2.0
        self.emailText.layer.borderColor = UIColor.black.cgColor
        self.emailText.clipsToBounds = true
        self.emailText.delegate = self
        self.emailText.layer.borderWidth = 1.0
        self.emailText.frame = CGRect(x: 100, y: 205
            , width: 150, height: 30)
        self.firstView.addSubview(emailText)
        self.emailErr.frame = CGRect(x: 100, y: 240, width: 150, height: 15)
        self.firstView.addSubview(emailErr)
        
        self.otp1.frame = CGRect(x: 25, y: 25, width: 20, height: 50)
        self.secondview.addSubview(otp1)
        self.otp1.keyboardType = UIKeyboardType.numberPad
        self.otp1l.frame = CGRect(x: 25, y: 75, width: 20, height: 2)
        self.otp1l.backgroundColor = UIColor.black
        self.secondview.addSubview(otp1l)
        
        
        
        
        self.otp2.frame = CGRect(x: (45+65), y: 25, width: 20, height: 50)
        self.secondview.addSubview(otp2)
        self.otp2l.frame = CGRect(x: (45+65), y: 75, width: 20, height: 2)
        self.otp2l.backgroundColor = UIColor.black
        self.otp2.keyboardType = UIKeyboardType.numberPad
        self.secondview.addSubview(otp2l)
        
        self.otp3.frame = CGRect(x: (45+65+20+65), y: 25, width: 20, height: 50)
        self.secondview.addSubview(otp3)
        self.otp3l.frame = CGRect(x: (45+65+20+65), y: 75, width: 20, height: 2)
        self.otp3l.backgroundColor = UIColor.black
        self.otp3.keyboardType = UIKeyboardType.numberPad
        self.secondview.addSubview(otp3l)
        
        self.otp4.frame = CGRect(x: (45+65+20+65+20+55), y: 25, width: 20, height: 50)
        self.secondview.addSubview(otp4)
        self.otp4l.frame = CGRect(x: (45+65+20+65+20+55), y: 75, width: 20, height: 2)
        self.otp4l.backgroundColor = UIColor.black
        self.otp1.delegate = self
        self.otp4.keyboardType = UIKeyboardType.numberPad
        self.otp2.delegate = self
        self.otp3.delegate = self
        self.otp4.delegate = self
        self.secondview.addSubview(otp4l)
        
        otp1.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: UIControl.Event.editingChanged)
        otp2.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: UIControl.Event.editingChanged)
        otp3.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: UIControl.Event.editingChanged)
        otp4.addTarget(self, action: #selector(self.textFieldDidChange(textField:)), for: UIControl.Event.editingChanged)
        
        
        
        
        
        
        
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    @objc func textFieldDidChange(textField: UITextField){
        let text = textField.text
        if  text?.count == 1 {
            switch textField{
            case otp1:
                otp2.becomeFirstResponder()
            case otp2:
                otp3.becomeFirstResponder()
            case otp3:
                otp4.becomeFirstResponder()
            case otp4:
                otp4.resignFirstResponder()
            default:
                break
            }
        }
        if  text?.count == 0 {
            switch textField{
            case otp1:
                otp1.becomeFirstResponder()
            case otp2:
                otp1.becomeFirstResponder()
            case otp3:
                otp2.becomeFirstResponder()
            case otp4:
                otp3.becomeFirstResponder()
            default:
                break
            }
        }
        else{
            
        }
    }
   
    @objc func doneButtonAction(){
        
        
        
       self.addressText.becomeFirstResponder()
        
        if(phoneText.text == "")
        {
            phoneErr.text = "Field is Empty"
            
            phoneFlag = 1
        }
        else{
            phoneErr.text = ""
            
            phoneFlag = 0
        }
        
    }
    func validateEmail(enteredEmail:String) -> Bool {
        
        let emailFormat = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,64}"
        let emailPredicate = NSPredicate(format:"SELF MATCHES %@", emailFormat)
        return emailPredicate.evaluate(with: enteredEmail)
        
    }

    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        if textField == self.nameText{
            self.phoneText.becomeFirstResponder()
            if(nameText.text == "")
            {
                self.nameErr.text = "Field is Empty"
                
                nameFlag = 1
            }
            else
            {
                nameErr.text = ""
                
                nameFlag = 0
            }
        }
        
        if textField == self.addressText{
            self.emailText.becomeFirstResponder()
            if(addressText.text == "")
            {
                addressErr.text = "Field is Empty"
                
                addressFlag = 1
            }
            else{
                addressErr.text = ""
                
                addressFlag = 0
            }
        }
        if textField == self.emailText{
            self.emailText.resignFirstResponder()
            if (!(validateEmail(enteredEmail: self.emailText.text ?? "")))
            {
                emailErr.text = "Email is invalid"
                
                emailFlag = 1
                
            }
               
            else{
                emailErr.text = ""
                
                emailFlag = 0
            }
        }
        
        
        return true
    }
    
    func textFieldDidBeginEditing(_ textField: UITextField) {
        print("TextField did begin editing method called")
        
        if textField == self.nameText{
            nameErr.text = ""
            nameFlag=0
            
        }
        if textField == self.phoneText{
            phoneErr.text = ""
            phoneFlag=0
        }
        if textField == self.addressText{
            addressErr.text = ""
            addressFlag=0
        }
        if textField == self.emailText{
            emailErr.text = ""
            emailFlag=0
        }
        
     if textField == self.otp1{
            self.otp1.text = ""
        }
//        if textField == self.otp2{
//            textField.text = ""
//        }
    }


}

